<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `wxq_user`;");
E_C("CREATE TABLE `wxq_user` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `account` varchar(64) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `password` char(32) NOT NULL,
  `last_login_time` int(11) unsigned DEFAULT '0',
  `last_login_ip` varchar(40) DEFAULT NULL,
  `login_count` mediumint(8) unsigned DEFAULT '0',
  `error_count` mediumint(8) DEFAULT '0',
  `error_login_time` int(11) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `role_id` mediumint(9) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8");
E_D("replace into `wxq_user` values('1','admin','超级管理员','ef78073155d68f390c6e2a1cb63d1cfc','1422872851','106.118.96.179','190','0','1422843017','','','1403882677','1408583500','1','0');");
E_D("replace into `wxq_user` values('3','admin11','黄生','413cb80b735234c64f8627eaa390da00','1420797417','14.18.29.244','4','0',NULL,'','','1420706479','1420792225','1','9');");
E_D("replace into `wxq_user` values('4','admin21','黄成','490874df393be07d46b1cfdc7aa88037','0',NULL,'0','0',NULL,'','','1420793188','0','1','9');");
E_D("replace into `wxq_user` values('5','admin31','黄成','579d9ec9d0c3d687aaa91289ac2854e4','1420877892','123.183.132.53','2','0',NULL,'','','1420793476','0','1','9');");
E_D("replace into `wxq_user` values('6','admin41','黄成','6ebe76c9fb411be97b3b0d48b791a7c9','1421120132','113.13.96.189','5','0',NULL,'','','1420795678','0','1','9');");
E_D("replace into `wxq_user` values('7','admin51','123987','125d0d502244655321fd3c3daf0dc440','1421084783','113.57.191.54','2','0',NULL,'','','1421084547','0','1','9');");

require("../../inc/footer.php");
?>