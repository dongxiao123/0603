<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `wxq_tjdate`;");
E_C("CREATE TABLE `wxq_tjdate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `create_date` int(11) DEFAULT NULL,
  `create_num` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8");
E_D("replace into `wxq_tjdate` values('1','20140627','38');");
E_D("replace into `wxq_tjdate` values('2','20140628','1116');");
E_D("replace into `wxq_tjdate` values('3','20140629','2473');");
E_D("replace into `wxq_tjdate` values('4','20140630','2040');");
E_D("replace into `wxq_tjdate` values('5','20140701','3145');");
E_D("replace into `wxq_tjdate` values('6','20140702','3850');");
E_D("replace into `wxq_tjdate` values('7','20140703','3764');");
E_D("replace into `wxq_tjdate` values('8','20140704','2343');");
E_D("replace into `wxq_tjdate` values('9','20140705','2162');");
E_D("replace into `wxq_tjdate` values('10','20140706','2900');");
E_D("replace into `wxq_tjdate` values('11','20140707','3575');");
E_D("replace into `wxq_tjdate` values('12','20140708','4506');");
E_D("replace into `wxq_tjdate` values('13','20140709','5227');");
E_D("replace into `wxq_tjdate` values('14','20140710','4798');");
E_D("replace into `wxq_tjdate` values('15','20140711','3362');");
E_D("replace into `wxq_tjdate` values('16','20140712','2934');");
E_D("replace into `wxq_tjdate` values('17','20140713','3045');");
E_D("replace into `wxq_tjdate` values('18','20140714','4503');");
E_D("replace into `wxq_tjdate` values('19','20140715','3780');");
E_D("replace into `wxq_tjdate` values('20','20140716','4817');");
E_D("replace into `wxq_tjdate` values('21','20140717','4924');");
E_D("replace into `wxq_tjdate` values('22','20140718','4784');");
E_D("replace into `wxq_tjdate` values('23','20140719','3364');");
E_D("replace into `wxq_tjdate` values('24','20140720','1750');");
E_D("replace into `wxq_tjdate` values('25','20140721','2610');");
E_D("replace into `wxq_tjdate` values('26','20140722','3146');");
E_D("replace into `wxq_tjdate` values('27','20140723','4329');");
E_D("replace into `wxq_tjdate` values('28','20140724','2339');");
E_D("replace into `wxq_tjdate` values('29','20140807','47');");
E_D("replace into `wxq_tjdate` values('30','20140808','21');");
E_D("replace into `wxq_tjdate` values('31','20140809','26');");
E_D("replace into `wxq_tjdate` values('32','20140810','6');");
E_D("replace into `wxq_tjdate` values('33','20140811','21');");
E_D("replace into `wxq_tjdate` values('34','20140812','90');");
E_D("replace into `wxq_tjdate` values('35','20140813','36');");
E_D("replace into `wxq_tjdate` values('36','20140814','27');");
E_D("replace into `wxq_tjdate` values('37','20140815','5');");
E_D("replace into `wxq_tjdate` values('38','20140821','44');");
E_D("replace into `wxq_tjdate` values('39','20141205','46');");
E_D("replace into `wxq_tjdate` values('40','20141206','50');");
E_D("replace into `wxq_tjdate` values('41','20141207','9');");
E_D("replace into `wxq_tjdate` values('42','20141208','84');");
E_D("replace into `wxq_tjdate` values('43','20141209','223');");
E_D("replace into `wxq_tjdate` values('44','20141210','162');");
E_D("replace into `wxq_tjdate` values('45','20141211','270');");
E_D("replace into `wxq_tjdate` values('46','20141211','1');");
E_D("replace into `wxq_tjdate` values('47','20141212','431');");
E_D("replace into `wxq_tjdate` values('48','20141213','120');");
E_D("replace into `wxq_tjdate` values('49','20141221','81');");
E_D("replace into `wxq_tjdate` values('50','20141222','89');");
E_D("replace into `wxq_tjdate` values('51','20141223','101');");
E_D("replace into `wxq_tjdate` values('52','20141224','35');");
E_D("replace into `wxq_tjdate` values('53','20141225','266');");
E_D("replace into `wxq_tjdate` values('54','20141226','3');");
E_D("replace into `wxq_tjdate` values('55','20141227','233');");
E_D("replace into `wxq_tjdate` values('56','20141228','170');");
E_D("replace into `wxq_tjdate` values('57','20141229','89');");
E_D("replace into `wxq_tjdate` values('58','20141230','307');");
E_D("replace into `wxq_tjdate` values('59','20141231','581');");
E_D("replace into `wxq_tjdate` values('60','20150101','157');");
E_D("replace into `wxq_tjdate` values('61','20150102','109');");
E_D("replace into `wxq_tjdate` values('62','20150103','119');");
E_D("replace into `wxq_tjdate` values('63','20150104','561');");
E_D("replace into `wxq_tjdate` values('64','20150105','147');");
E_D("replace into `wxq_tjdate` values('65','20150106','235');");
E_D("replace into `wxq_tjdate` values('66','20150107','219');");
E_D("replace into `wxq_tjdate` values('67','20150108','207');");
E_D("replace into `wxq_tjdate` values('68','20150109','630');");
E_D("replace into `wxq_tjdate` values('69','20150110','927');");
E_D("replace into `wxq_tjdate` values('70','20150111','823');");
E_D("replace into `wxq_tjdate` values('71','20150112','706');");
E_D("replace into `wxq_tjdate` values('72','20150113','657');");
E_D("replace into `wxq_tjdate` values('73','20150114','482');");
E_D("replace into `wxq_tjdate` values('74','20150115','580');");
E_D("replace into `wxq_tjdate` values('75','20150116','581');");
E_D("replace into `wxq_tjdate` values('76','20150117','307');");
E_D("replace into `wxq_tjdate` values('77','20150118','52');");
E_D("replace into `wxq_tjdate` values('78','20150119','1045');");
E_D("replace into `wxq_tjdate` values('79','20150120','764');");
E_D("replace into `wxq_tjdate` values('80','20150121','194');");
E_D("replace into `wxq_tjdate` values('81','20150122','348');");
E_D("replace into `wxq_tjdate` values('82','20150123','10');");
E_D("replace into `wxq_tjdate` values('83','20150124','20');");
E_D("replace into `wxq_tjdate` values('84','20150125','36');");
E_D("replace into `wxq_tjdate` values('85','20150126','168');");
E_D("replace into `wxq_tjdate` values('86','20150127','205');");
E_D("replace into `wxq_tjdate` values('87','20150128','378');");
E_D("replace into `wxq_tjdate` values('88','20150129','345');");
E_D("replace into `wxq_tjdate` values('89','20150130','42');");
E_D("replace into `wxq_tjdate` values('90','20150131','151');");
E_D("replace into `wxq_tjdate` values('91','20150201','567');");
E_D("replace into `wxq_tjdate` values('92','20150202','528');");
E_D("replace into `wxq_tjdate` values('93','20150203','36');");

require("../../inc/footer.php");
?>