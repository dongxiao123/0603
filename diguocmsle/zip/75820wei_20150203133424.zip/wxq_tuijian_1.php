<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `wxq_tuijian`;");
E_C("CREATE TABLE `wxq_tuijian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wxid` int(11) DEFAULT NULL,
  `pubaccount` varchar(50) DEFAULT NULL,
  `memberid` int(11) DEFAULT NULL,
  `membername` varchar(50) DEFAULT NULL,
  `recommendid` int(11) DEFAULT NULL,
  `timelimit` tinyint(4) DEFAULT NULL,
  `starttime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `intergral` int(11) DEFAULT '0',
  `intergralnum` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=228 DEFAULT CHARSET=utf8");
E_D("replace into `wxq_tuijian` values('227','4943','幽兰范儿',NULL,NULL,'1','0','0','0','0',NULL,'1','1422455365');");
E_D("replace into `wxq_tuijian` values('213','4968','微商互推平台',NULL,NULL,'1','0','0','0','0',NULL,'1','1421399079');");
E_D("replace into `wxq_tuijian` values('214','4974','第一微商',NULL,NULL,'1','0','0','0','0',NULL,'1','1421399105');");
E_D("replace into `wxq_tuijian` values('215','4960','微商交流群',NULL,NULL,'1','0','0','0','0',NULL,'1','1421399127');");
E_D("replace into `wxq_tuijian` values('216','4957','微商运营秘籍',NULL,NULL,'1','0','0','0','0',NULL,'1','1421399160');");
E_D("replace into `wxq_tuijian` values('217','4975','思埠总代',NULL,NULL,'1','0','0','0','0',NULL,'1','1421399183');");
E_D("replace into `wxq_tuijian` values('226','4980','木子 - 微商代理',NULL,NULL,'1','0','0','0','0',NULL,'1','1422436127');");
E_D("replace into `wxq_tuijian` values('221','4992','Alan',NULL,NULL,'1','0','0','0','0',NULL,'1','1422434016');");
E_D("replace into `wxq_tuijian` values('222','4990','蓝蓓丽新品系列品牌招商',NULL,NULL,'1','0','0','0','0',NULL,'1','1422434026');");
E_D("replace into `wxq_tuijian` values('223','4988','阐幽护肤品化妆品，美衣美鞋',NULL,NULL,'1','0','0','0','0',NULL,'1','1422434035');");
E_D("replace into `wxq_tuijian` values('224','4971','美丽联盟',NULL,NULL,'1','0','0','0','0',NULL,'1','1422434071');");
E_D("replace into `wxq_tuijian` values('225','4948','诚招微商',NULL,NULL,'1','0','0','0','0',NULL,'1','1422434185');");

require("../../inc/footer.php");
?>