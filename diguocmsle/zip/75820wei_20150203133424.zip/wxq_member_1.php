<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `wxq_member`;");
E_C("CREATE TABLE `wxq_member` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` mediumint(9) NOT NULL,
  `account` varchar(64) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `password` char(32) NOT NULL,
  `wxaccount` varchar(100) NOT NULL COMMENT '个人微信号',
  `gender` tinyint(1) NOT NULL COMMENT '性别',
  `birthday` date NOT NULL COMMENT '生日',
  `province` int(6) NOT NULL COMMENT '省份',
  `city` int(6) NOT NULL COMMENT '城市',
  `last_login_time` int(11) unsigned DEFAULT '0',
  `last_login_ip` varchar(40) DEFAULT NULL,
  `login_count` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `amount` decimal(11,2) NOT NULL,
  `intergral` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL,
  `thumb` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8");
E_D("replace into `wxq_member` values('16','0','fffg52','','30926c80b3724a37df9a5f760eb509ec','','0','0000-00-00','0','0','1421741100','58.63.78.12','55','0.00','0','fffg52@163.com','','1','1419268017','1419268017','/2014/12/23/549850dc5e2e7.jpg');");
E_D("replace into `wxq_member` values('17','0','puzzle','','96e79218965eb72c92a549dd5a330112','','0','0000-00-00','0','0','1421131741','218.87.99.31','10','0.00','0','0focus0@gmail.com','','1','1420547443','1420547443',NULL);");
E_D("replace into `wxq_member` values('18','0','ying','','e10adc3949ba59abbe56e057f20f883e','','0','0000-00-00','0','0','1421112345','113.13.96.189','7','0.00','0','1007044106@qq.com','','1','1420620078','1420620078','/../../..//Uploads/php_avatar1_20150113093415_942_WB1HWR6M.jpg');");
E_D("replace into `wxq_member` values('19','0','weiai','','e10adc3949ba59abbe56e057f20f883e','','0','0000-00-00','0','0','1420769935','222.129.238.26','2','0.00','0','495453910@qq.com','','1','1420769899','1420769899',NULL);");
E_D("replace into `wxq_member` values('20','0','jay5260','','53fff802fde04a88f58afbe3b6198516','','0','0000-00-00','0','0','1420797892','14.18.29.244','2','0.00','0','254026972@qq.com','','1','1420797528','1420797528',NULL);");
E_D("replace into `wxq_member` values('21','0','zcash8','','25f9e794323b453885f5181f1b624d0b','','0','0000-00-00','0','0','1422876918','106.118.96.179','19','0.00','0','373584167@qq.com','','1','1420807219','1420807219',NULL);");
E_D("replace into `wxq_member` values('22','0','qingdianlonger','恩茜','7c990a2f22ea2b6b95313757c2e5680f','jpmb2015','2','1991-02-24','2','506','1420870161','222.129.238.26','1','0.00','0','','','1','1420870129','1420870129',NULL);");
E_D("replace into `wxq_member` values('23','0','test16937','无聊的法国文艺片','205b40725923a2e34c32d1f8ff2a31f4','','0','0000-00-00','-1','-1','1420873970','222.129.238.26','1','0.00','0','','','1','1420873954','1420873954',NULL);");
E_D("replace into `wxq_member` values('24','0','lgl211','','d9076be567cd8e39b7aec8d4c264b4d3','','0','0000-00-00','0','0','1420988810','113.57.142.182','1','0.00','0','519516274@qq.com','','1','1420988784','1420988784',NULL);");
E_D("replace into `wxq_member` values('25','0','one335','','25f9e794323b453885f5181f1b624d0b','','0','0000-00-00','0','0','1422872715','106.118.96.179','30','0.00','0','373584167@qq.com','','1','1421307499','1421307499',NULL);");
E_D("replace into `wxq_member` values('26','33','zcash88','','3151b6eb6a85e40ee353205d021d2dc3','','0','0000-00-00','0','0','1422263006','120.6.136.220','1','0.00','0','wei163@qq.com','','1','1422262985','1422362301',NULL);");

require("../../inc/footer.php");
?>