<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `wxq_advert`;");
E_C("CREATE TABLE `wxq_advert` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `adname` varchar(50) NOT NULL,
  `adtag` varchar(50) NOT NULL,
  `timelimit` tinyint(4) DEFAULT NULL,
  `starttime` int(11) NOT NULL,
  `endtime` int(11) NOT NULL,
  `adcontent` text,
  `adpastcontent` text,
  `status` tinyint(1) NOT NULL,
  `create_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `siteid` (`endtime`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8");
E_D("replace into `wxq_advert` values('9','列表页右侧','listrightside','0','0','0','<a href=\"http://www.yufu5.com\" target=\"_blank\"><img src=\"__ROOT__/Uploads/2013/05/23/ad260x120.jpg\"></a>','<a href=\"http://www.yufu5.com\" target=\"_blank\"><img src=\"__ROOT__/Uploads/2013/05/23/ad260x120.jpg\"></a>','1','1370781196');");
E_D("replace into `wxq_advert` values('10','首页flash','flashad01','0','0','0','<script type=\"text/javascript\"> \r\n                                                \r\n                                                \$(document).ready(function(){\r\n                                                jQuery.yufu.loadFlashSwf({\r\n                                                   swfUrl : \"../Public/images/ad260x405.swf\",\r\n                                                   clientId : \"FlashAd01\",\r\n                                                   width : \"260\",\r\n                                                   height : \"405\"\r\n                                                });});\r\n                                                </script>','<script type=\"text/javascript\"> \r\n                                                \r\n                                                \$(document).ready(function(){\r\n                                                jQuery.yufu.loadFlashSwf({\r\n                                                   swfUrl : \"../Public/images/ad260x405.swf\",\r\n                                                   clientId : \"FlashAd01\",\r\n                                                   width : \"260\",\r\n                                                   height : \"405\"\r\n                                                });});\r\n                                                </script>','1','1369381102');");
E_D("replace into `wxq_advert` values('11','详细页面右侧','detailright','0','0','0','<a href=\"www.yufu5.com\" target=\"_blank\"><img src=\"/yufucms_wx/Uploads/2013/07/11/250x250.jpg\" /></a>','','1','1373619282');");

require("../../inc/footer.php");
?>