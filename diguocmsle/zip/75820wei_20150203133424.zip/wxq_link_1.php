<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `wxq_link`;");
E_C("CREATE TABLE `wxq_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `linktype` tinyint(1) NOT NULL,
  `type` int(11) DEFAULT NULL,
  `name` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `listorder` smallint(5) NOT NULL,
  `create_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8");
E_D("replace into `wxq_link` values('1','0','0','百度','http://www.baidu.com','','0','1404028018');");
E_D("replace into `wxq_link` values('2','0','0','新浪','http://www.sina.com.cn/','','17','1369396621');");
E_D("replace into `wxq_link` values('3','0','0','搜狐','http://www.sohu.com/','','3','1404028026');");
E_D("replace into `wxq_link` values('10','0','0','微信','http://weixin.qq.com/','','22','1407813077');");

require("../../inc/footer.php");
?>