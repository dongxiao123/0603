<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `wxq_comment`;");
E_C("CREATE TABLE `wxq_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `modelname` varchar(50) DEFAULT NULL,
  `objectid` int(11) NOT NULL,
  `memberid` int(11) DEFAULT NULL,
  `membername` varchar(50) DEFAULT NULL,
  `content` text,
  `ip` varchar(50) DEFAULT NULL,
  `reply` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8");
E_D("replace into `wxq_comment` values('1','0','120','Weixin','186','2','shiyue','这个微信很牛B啊。。。哈哈','112.117.215.153','0','1','1404624948');");
E_D("replace into `wxq_comment` values('2','0','66','Weixin','54','1','tong850066186','ceshiyixia ','127.0.0.1','0','1','1418297710');");
E_D("replace into `wxq_comment` values('3','2','66','Weixin','54','13','tong850066186','sdf ','127.0.0.1','1','1','1418298138');");
E_D("replace into `wxq_comment` values('4','3','66','Weixin','54','13','tong850066186','sdaf','127.0.0.1','1','1','1418298884');");
E_D("replace into `wxq_comment` values('5','0','160','Weixin','4923','18','ying','52454gfytg 胡换个','113.13.105.65','0','1','1420855523');");
E_D("replace into `wxq_comment` values('6','0','228','Weixin','4926','23','test16937','这是一条十五字评论，算上这几个字。','222.129.238.26','0','1','1420876882');");

require("../../inc/footer.php");
?>