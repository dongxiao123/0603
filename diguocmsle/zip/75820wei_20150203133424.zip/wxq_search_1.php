<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `wxq_search`;");
E_C("CREATE TABLE `wxq_search` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `search` varchar(20) NOT NULL,
  `hits` int(11) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=utf8");
E_D("replace into `wxq_search` values('2','十月科技','105','1','1405056792');");
E_D("replace into `wxq_search` values('52','百度音乐','2','1','1406030106');");
E_D("replace into `wxq_search` values('51','猫扑','2','1','1406030085');");
E_D("replace into `wxq_search` values('50','QQ空间','1','1','1406030027');");
E_D("replace into `wxq_search` values('49','百合网','1','1','1406029813');");
E_D("replace into `wxq_search` values('48','成塑电缆','2','1','1405934035');");
E_D("replace into `wxq_search` values('13','新鲜事','1666','1','1405056922');");
E_D("replace into `wxq_search` values('14','蓝蓓丽','3108','1','1421757526');");
E_D("replace into `wxq_search` values('47','湖北新闻','3','1','1405501986');");
E_D("replace into `wxq_search` values('46','当当','2','1','1405394031');");
E_D("replace into `wxq_search` values('45','韩束','2083','1','1421757511');");
E_D("replace into `wxq_search` values('44','国美','1','1','1405393792');");
E_D("replace into `wxq_search` values('43','何洁','2','1','1405151941');");
E_D("replace into `wxq_search` values('42','翡翠','2','1','1405135843');");
E_D("replace into `wxq_search` values('53','搜房网','1','1','1406030136');");
E_D("replace into `wxq_search` values('54','测试','2','1','1417790160');");
E_D("replace into `wxq_search` values('55','美容','1','1','1418091087');");

require("../../inc/footer.php");
?>